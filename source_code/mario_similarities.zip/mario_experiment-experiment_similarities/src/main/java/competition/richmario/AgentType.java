package competition.richmario;

/**
 * Created by Dev on 16/05/2017.
 */
public enum AgentType {
    BasicQLearning, Abstraction, RewardShaping, Similarities, AbstractionBasicQLearning
}
