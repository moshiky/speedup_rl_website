/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package competition.advice;


/**
 *
 * @author timbrys
 */
public enum AgentType {
    RegularAdvice, HistoricAdvice, TerminateAdvice
}
