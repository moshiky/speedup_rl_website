/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package competition.aamas15;


/**
 *
 * @author timbrys
 */
public enum AgentType {
    NoShaping, SingleShaping, Supershaping, Linear, AOS, Ranking
}
