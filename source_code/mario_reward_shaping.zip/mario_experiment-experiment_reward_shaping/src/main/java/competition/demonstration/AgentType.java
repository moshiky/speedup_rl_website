/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package competition.demonstration;


/**
 *
 * @author timbrys
 */
public enum AgentType {
    NoShaping, DemonstrationShaping
}
