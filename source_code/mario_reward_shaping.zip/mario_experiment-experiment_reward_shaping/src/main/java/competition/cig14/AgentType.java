/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package competition.cig14;

/**
 *
 * @author timbrys
 */
public enum AgentType {
    Random, NoShaping, SingleShaping, Linear, BestLinear, ROS, AOS, CAOS, Ranking, NormalizedRanking
}
