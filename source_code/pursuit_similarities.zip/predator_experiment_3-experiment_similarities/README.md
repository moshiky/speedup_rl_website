# predator_experiment_3

Based on Tim Brys, Ann Nowe, Daniel Kudenko and Matthew E. Taylor code for the article "Combining Multiple Correlated Reward and Shaping Signals by Measuring Confidence".

Original code link:
https://www.researchgate.net/publication/261722569_Java_Code_Adaptive_Objective_Selection_Pursuit_Domain
