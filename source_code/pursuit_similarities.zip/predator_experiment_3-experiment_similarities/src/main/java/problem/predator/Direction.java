/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package problem.predator;

/**
 * @author timbrys
 */
public enum Direction {
    Up, Down, Left, Right, None
}
