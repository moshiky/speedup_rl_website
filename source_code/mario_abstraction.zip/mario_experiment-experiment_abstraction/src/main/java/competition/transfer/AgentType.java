/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package competition.transfer;

import competition.advice.*;
import competition.aamas15.*;


/**
 *
 * @author timbrys
 */
public enum AgentType {
    NoShaping, SingleShaping, Supershaping, Linear, AOS, Ranking
}
